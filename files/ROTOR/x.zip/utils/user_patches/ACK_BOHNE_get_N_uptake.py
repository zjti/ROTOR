def get_N_uptake(self):
    return -12

