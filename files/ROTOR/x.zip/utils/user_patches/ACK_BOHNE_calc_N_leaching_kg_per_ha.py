

def calc(self):
    if 1 == self.calc_N_leaching_kg_per_ha():
        return
    return self.calc_yield_dt_fm_per_ha()

calc(DBG)