def calc_opts(ff):
    R = {}
    print('a',ff)
    for k,v in ff.items():
        R[k] = {'zw_opt' : True}

    return R
