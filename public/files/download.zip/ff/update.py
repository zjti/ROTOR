import json
import config
from config import SOIL

from crops.utils import get_crop_dict

def jahr_key(i):
    return str(i+1)

def updateFFlength(ffolge, NJahre):
    print(ffolge,NJahre)

    valid_keys = []
    for i in range(NJahre):
        k = jahr_key(i)
        valid_keys.append(k)
        if ( k not in ffolge):
            ffolge[k] = {'crop':'',
                        'vis':{},
                         'restr_select_phyto':False,
                         'restr_select_time':True,
                        }

    old_keys = [key for key in ffolge.keys() if key not in valid_keys ]
    for old_key in old_keys:
        del ffolge[old_key]
    
    return ffolge


old_ffolge_json = None

py_FFolge = {}
crop_dict = get_crop_dict()

def updateFF(ffolge ):

    print(SOIL)

    global old_ffolge_json,crop_dict
    
    if json.dumps(ffolge, sort_keys=True, indent=2) == old_ffolge_json:
        # print('nothing new')
        return None
    else:
        print('updating..')

    #update py_folge
    for k,val in ffolge.items():
        if val['crop'] not in crop_dict:
            continue

        if k not in config.FFolge:
            config.FFolge[k] = ffolge[k]
        config.FFolge[k].update(ffolge[k])
        
        if k in py_FFolge:
            if type(py_FFolge[k]) != crop_dict[val['crop']]:   
                py_FFolge[k] = crop_dict[val['crop']](k)    
        else:
            py_FFolge[k] = crop_dict[val['crop']](k)

    #update vis
    for k,val in py_FFolge.items():
        ffolge[k]['vis'] = val.get_vis()
        if 'dung_tab' in ffolge[k]['vis']:
            if 'dung_menge' not in ffolge[k]:
                ffolge[k]['dung_menge'] = {}

        models, always_update = val.get_models()
        for modname,modval in models.items():
            if modname not in ffolge[k]:
                ffolge[k][modname] = modval
            if modname in always_update:
                ffolge[k][modname] = modval
    
    
    config.FFolge = ffolge
    config.py_FFolge = py_FFolge
    old_ffolge_json = json.dumps(ffolge, sort_keys=True, indent=2) 
    return ffolge
    