from typing import Optional, Dict, Type
from .. import cropdata 
from .. import crop
import config


class WN_WEIZEN(crop.Getreide):
    """Winter wheat implementation"""
    def __init__(self, jahr_key):
        crop_data = cropdata.WN_WEIZEN
        
        super().__init__(crop_data, jahr_key)

    def calc_yield_dt_fm_per_ha(self,EF=2):
         
        AZ = config.SOIL['ACKERZAHL']['default']
        print('a')
        if EF == 3:
            E = -0.0053 * AZ**2 + 1.57 * AZ - 16.7
        elif EF == 2:
            E = -0.0047 * AZ**2 + 1.41 * AZ - 16.8
        elif EF == 1:
            E = -0.0042 * AZ**2 + 1.25 * AZ - 16.9
        return E

    def get_vis(self):
        return {'ertrag_tab':True, 'dung_tab':True}

    def get_models(self):
        # v-model:amounts="FF[jahr].dung_menge"
        # :has_herbst_gabe="FF[jahr].has_herbst_gabe"
        #  v-model="FF[props.jahr].yield_dt"
        # :hint="
        #   FF[props.jahr].yield_dt_corrected
        
        yield_from_fert_dt = self.calc_yield_from_fert_dt()
        yield_dt = self.calc_yield_dt_fm_per_ha()  + yield_from_fert_dt
        print('z',yield_from_fert_dt)
        always_update  = ['yield_dt_calc','yield_from_fert_dt']
        ffcomp = config.FFolge[self.jahr_key]
        if 'yield_dt_calc' in ffcomp:
            if ffcomp['yield_dt_calc'] == ffcomp['yield_dt_corrected']:
                always_update += ['yield_dt_corrected']
        return {'has_herbst_gabe':True, 'dung_menge':{} , 
                'yield_dt_calc': yield_dt, 
                'yield_dt_corrected': yield_dt ,
                'yield_from_fert_dt':yield_from_fert_dt} , always_update
               
        
    def get_crop_opts(self):
        return ["STROH","ZW_VOR","ZW_NACH","US_VOR","US_NACH","DUNG","REDUCED"]