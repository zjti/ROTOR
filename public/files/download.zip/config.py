SOIL = {}
PHYTO_DELAY = {}
FFolge = {}
py_FFolge = {}
PHYTO_DELAY_TIME = {} 